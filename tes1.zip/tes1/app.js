const express = require("express");
const bodyParser = require("body-parser");
const nano = require("nano")("http://admin:123@127.0.0.1:5984"); // Update with your CouchDB credentials

const app = express();
const db = nano.use("todos");

app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

// Routes

app.get("/", async (req, res) => {
  try {
    const todos = await db.list({ include_docs: true });
    res.render("index", { todos: todos.rows.map((row) => row.doc) });
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
});

app.post("/add", async (req, res) => {
  const { task, description } = req.body;

  try {
    await db.insert({ task, description });
    res.redirect("/");
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
});

app.get("/edit/:id", async (req, res) => {
  const id = req.params.id;

  try {
    const todo = await db.get(id);
    res.render("edit", { todo });
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
});

app.post("/update/:id", async (req, res) => {
  const id = req.params.id;
  const { task, description } = req.body;

  try {
    const todo = await db.get(id);
    todo.task = task;
    todo.description = description;
    await db.insert(todo);
    res.redirect("/");
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
});

app.get("/delete/:id", async (req, res) => {
  const id = req.params.id;

  try {
    const todo = await db.get(id);
    await db.destroy(todo._id, todo._rev);
    res.redirect("/");
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal Server Error");
  }
});

// Server

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
